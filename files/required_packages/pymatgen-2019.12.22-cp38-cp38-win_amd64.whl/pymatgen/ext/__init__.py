"""
This package implements interfaces to various external data sources and
utilities. For example, the Materials Project, the Crystallography Open
Database, etc.
"""
